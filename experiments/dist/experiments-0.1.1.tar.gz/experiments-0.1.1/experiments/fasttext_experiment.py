"""
    Experiment module
"""

import pathlib

import matplotlib.pyplot as plt
import pyarrow.dataset as ds
import pandas as pd

import fasttext
import experiments.dimension_generator as dg
import experiments.reddit_posts as ps
import experiments.ranking as rk


def _mkdir_if_not_exists(_dir):
    if not _dir.exists():
        _dir.mkdir(parents=True)
    return _dir


class FasttextExperiment:
    """
        Experiments Class
    """
    def __init__(self, year, working_dir, results_dir, post_type, dataset):
        self.year = str(year)
        self.working_dir = pathlib.Path(working_dir)
        self.results_folder = str(results_dir)
        self.post_type = post_type
        self.dataset = str(dataset)

    @property
    def _base_dataset_dir(self):
        return self._base_parent_dir / self.dataset

    @property
    def _base_parent_dir(self):
        return self.working_dir / self.posts_type / self.year

    @property
    def _data_pathname(self):
        return self._base_dataset_dir / 'data'

    @property
    def _truncated_data_pathname(self):
        truncated_dir = self._base_parent_dir / 'truncated'
        return _mkdir_if_not_exists(truncated_dir)

    @property
    def _results_dir(self):
        results_dir = self._base_dataset_dir / self.results_folder
        return _mkdir_if_not_exists(results_dir)

    def _result_path(self, filename):
        return self._results_dir / filename

    @property
    def _subreddits_pathname(self):
        return self._result_path('subreddits.txt')

    @property
    def _fasttext_model_pathname(self):
        return self._result_path('subreddits.bin')

    @property
    def _embedding_pathname(self):
        return self._result_path('embeddings.csv')

    def apply_texts(self):
        """
            Applies text command

            Generates a single file with all subreddits posts text.
            Each paragraph corresponds to a single subreddit.
            Only top 10k most relevant subreddits are taken in consideration.
        """
        reddit_posts = self._get_reddit_posts()
        reddit_posts.generate_text()

    def apply_truncate(self):
        """
            Applies truncate command

            Generates a truncated dataset by keeping only the most relevant posts of each subreddit.
            Each subreddit has a threshold of 10k bytes.
            Only top 10k most relevant subreddits are taken in consideration.
        """
        reddit_posts = self._get_reddit_posts()
        data = reddit_posts.truncate_dataset()
        data.to_parquet(self._truncated_data_pathname / 'truncated_data.parquet')

    def _get_reddit_posts(self):
        dataset = ds.dataset(self._data_pathname, format="parquet")
        reddit_posts = ps.RedditPosts(dataset, self, self.post_type)
        return reddit_posts

    def write_text(self, text):
        """
            Consumes text of subreddit posts and appends it to a single file.
        """
        with open(self._subreddits_pathname, 'a', encoding='utf-8') as file:
            file.write(text + '\n')

    def apply_embeddings(self):
        """
            Applies embeddings command

            Generates embeddings for each subreddit in the given dataset and saves them to disk.
        """
        model_pathname = str(self._fasttext_model_pathname.absolute())
        model = fasttext.load_model(model_pathname)
        reddit_posts = self._get_reddit_posts()

        tf_idf = reddit_posts.generate_embeddings_for(model)
        tf_idf.to_csv(self._embedding_pathname)

    def _get_fasttext_scores(self) -> pd.DataFrame:
        data = pd.read_csv(self._embedding_pathname, index_col=0)
        generator = dg.DimensionGenerator(data)
        dimensions = generator.generate_dimensions_from_seeds([("democrats", "Conservative")])
        scores = dg.score_embedding(data, zip([self._dem_rep_field], dimensions))
        return scores

    def apply_compare(self):
        """
            Applies compare command

            Generates metrics and plots comparing our results to Waller's et al.
            Metrics include: RBO, Kendall Tau, T-Standard p-value, ROC AUC
            Plots include: bump chart, ROC AUC, violin plot, kde plot
        """
        fasttext_ranking = (self._get_fasttext_scores().to_dict(orient='dict'))[self._dem_rep_field]
        ranking = rk.Ranking(fasttext_ranking)
        metrics = ranking.compare_ranking()

        self._save_metrics(metrics.classification_metrics, 'classification_metrics.csv')
        self._save_metrics(metrics.ranking_metrics, 'ranking_metrics.csv')

        for name, fig in metrics.plots.items():
            fig.savefig(
                self._result_path(f"{name}.png"),
                dpi=300,
                bbox_inches='tight')
            plt.close(fig)

    def _save_metrics(self, metrics, filename):
        pd.DataFrame(metrics).to_csv(self._result_path(filename))

    @property
    def _dem_rep_field(self):
        return 'dem_rep'

    @property
    def posts_type(self):
        """
         Gets corresponding dataset folder name based on posts type
        """
        return self.post_type.posts_type(self)

    @property
    def submissions_dataset(self):
        """
         Dataset folder name for submissions
        """
        return 'pushshift-reddit'

    @property
    def comments_dataset(self):
        """
         Dataset folder name for comments
        """
        return 'pushshift-reddit-comments'
